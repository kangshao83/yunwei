PATH=/usr/local/webserver/libs/cmake/bin:$PATH
export PATH
